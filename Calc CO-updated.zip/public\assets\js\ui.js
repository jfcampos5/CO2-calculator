﻿import { calculateEmissions } from './calculator.js'; export async function initUI(){ console.log('UI init'); }
