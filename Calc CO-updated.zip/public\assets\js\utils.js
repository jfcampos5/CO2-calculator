﻿export function fmtNumber(n,d=2){if(!isFinite(n))return 'â€
