﻿import { initUI } from './ui.js'; document.addEventListener('DOMContentLoaded', ()=>{ initUI(); });
